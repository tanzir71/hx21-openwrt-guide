# OPTIONAL community SSH configuration — read first

`HX21-ssh.bin` is a modified STOCK configuration, NOT OpenWrt firmware and NOT an official signed OpenWrt image. It was downloaded as inert data and has not been applied or audited for safety.

Source: [byjahidul/Imou-HX21](https://github.com/byjahidul/Imou-HX21), pinned commit `794117a14c7d563da5defbbb8cd005266e78769e`.
SHA-256 of this downloaded copy: `88d56f7d610a1cb32485527364cd23f120624a2f06e0f8fad6311c7c764434d0`.
This hash identifies the copy; it does not establish that the file is safe.

## The MAC/Factory warning

In [this group discussion](https://www.facebook.com/groups/383628147262547/permalink/1209221474703206/), Salman Shafi reported that his Factory backup already contained a changed MAC after using the SSH config file. This is an owner report, not an independently reproduced universal finding. A [separate claimed permanent fix](https://www.facebook.com/groups/383628147262547/permalink/1215483640743656/) did not publish a reproducible procedure in the comments reviewed.

Therefore:

1. Photograph the sticker and record stock UI/interface MACs BEFORE restoring anything.
2. First try stock SSH; some reported sessions already had it enabled.
3. If preserving untouched Factory data matters, use a properly identified 3.3 V UART route to enable SSH and back up first, or get competent hands-on help.
4. Backing up AFTER using this file is still important, but cannot recover unknown pre-unlock changes.
5. Never write a different router's Factory data, copy another owner's MAC, or run a generic `nvram`/Factory-patching recipe.

## If you choose and accept this route

On an isolated wired connection, open stock UI, usually `http://192.168.10.1`. First export your own stock web configuration privately. In the stock **Backup/Restore → Restore Configuration** function, select this `HX21-ssh.bin`. Do NOT select Firmware Upgrade, and do NOT upload it to OpenWrt LuCI.

The maintainer documents that after restore/reboot the web password is `12345678`, and SSH is `root` with an empty password. Stock UI credentials before the restore are whatever is currently configured; do not assume a default works on your unit. Do not expose the blank-password router to the Internet or a shared network. Proceed to the backup step immediately once SSH is available.

If the UI rejects the file, STOP. Do not rename a different model's unlock payload or force a firmware restore.

## UART alternative

Use a 3.3 V TTL USB-UART adapter and confirmed HX21 pad identification from the [device page](https://openwrt.org/toh/imou/hx21), not guessed pin order. Cross adapter TX to router RX, adapter RX to router TX, connect GND. **Do not connect VCC/VDD; do not use 5 V TTL or RS-232 voltage.** Router uses its own supply.

On the Mac, identify the actual adapter device with `ls /dev/cu.*`; use `screen /dev/cu.ACTUAL_DEVICE 115200` (replace the placeholder). Parameters: 115200, 8N1; no flow control. At a STOCK Linux root shell, `passwd` sets the root password and `dropbear -p 22` starts SSH if it is not already running. These are Linux-shell commands, not U-Boot commands. Return to this kit's backup step. Opening/soldering risks physical damage and warranty loss; this kit does not include guessed pad diagrams or an automated UART flashing tool.
