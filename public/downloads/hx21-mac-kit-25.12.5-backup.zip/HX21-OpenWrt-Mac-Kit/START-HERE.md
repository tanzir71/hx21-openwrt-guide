> BACKUP ARCHIVE ONLY. Check https://openwrt.org/toh/imou/hx21 and official repositories for current instructions, images and signatures before use. No device backups or private settings are included.

# HX21 → OpenWrt: your Mac kit

Prepared 2 September 2026. Public, portable copy of the Mac research kit.
Firmware: official OpenWrt 25.12.5, target `mediatek/filogic`, profile `imou_hx21`.

Nothing has been flashed, no router has been contacted, and no Mac network settings have been changed during preparation.

## Read before connecting anything

This is a staged first-install kit for the documented **stock Imou HX21**. Confirm the label and hardware revision against the [device page](https://openwrt.org/toh/imou/hx21). Do not use it for another model, or rerun the stock bootloader procedure on a router already running OpenWrt/ImmortalWrt. The backup helper stops if the stock partition map differs.

Bootloader/flash writes can brick the router. A working Ethernet adapter, reliable power, and verified private backups are prerequisites. If you cannot accept opening the router for recovery if necessary, pause before the first write.

Important: the optional SSH-unlock configuration has an owner-reported MAC/Factory-data concern. Read `optional-ssh-unlock/READ-BEFORE-USING.md` BEFORE uploading it. A backup taken after applying it cannot prove preservation of the original factory data. There is no automatic MAC-fix script in this kit.

## What you need

- This folder kept at `~/Desktop/HX21-OpenWrt-Mac-Kit` until finished; the SSH config uses that location.
- A USB-C/Thunderbolt Ethernet adapter if your Mac lacks Ethernet, and a good cable.
- Router power supply and stable power; keep the Mac plugged in and awake.
- At least 1 GiB free disk space, plus a second private destination for backups.
- ISP connection details: DHCP/PPPoE, PPPoE credentials, VLAN and any MAC binding. Record privately in `DEVICE-WORKSHEET.md`.
- A spare way to get online/read help if your home connection goes down.

No Homebrew, Python, Windows VM, WinSCP or Tftpd64 is required for the main path. The helpers use macOS tools already present on this Mac. Digital-signature checking is a separate optional GnuPG step in `sources/PROVENANCE.md`; downloaded-image SHA-256 checks have passed.

## Implementation order

1. Read this file and `guides/FLASHING-MAC.md` completely. Fill out `DEVICE-WORKSHEET.md` and photograph the sticker.
2. Double-click `01-Verify-Files.command`. Require success.
3. Wire Mac → HX21 LAN, disconnect router WAN, turn off Mac Wi-Fi/VPN/Internet Sharing. Set Ethernet IPv4 manually as below.
4. Double-click `02-Add-Stock-Address.command`. It asks before adding a temporary second Mac IP.
5. Check whether stock SSH already works. Only if needed, choose the optional unlock route or UART after reading its warning.
6. Double-click `03-Backup-Stock.command`. Require `BACKUP-COMPLETE.txt` and copy the entire resulting backup folder to a second private location.
7. Double-click `04-Start-TFTP.command`. Require the local transfer self-test to pass.
8. Follow `guides/FLASHING-MAC.md`, one block at a time. Destructive router commands are only in that guide, not in the double-click helpers.
9. Configure and test the installed router; then run `05-Stop-TFTP-and-Remove-Alias.command` and restore your previous Ethernet settings.

The numbers on helpers are an order, not permission to run them without the intervening guide steps. Admin-password prompts come from `sudo`; the password is not displayed or recorded.

## Mac Ethernet setup

Record your existing Ethernet settings first. In System Settings → Network → your **wired Ethernet adapter** → Details → TCP/IP, choose Configure IPv4: Manually:

| Setting | Value |
|---|---|
| IP address | `192.168.1.254` |
| Subnet mask | `255.255.255.0` |
| Router | `192.168.1.1` |
| DNS | Not needed for this isolated flashing link |

Then run helper 02. It adds `192.168.10.2/24` to the same wired interface. The Mac now has **both** addresses: one reaches stock firmware at `192.168.10.1`, the other serves TFTP and reaches OpenWrt at `192.168.1.1`. Do not put either router address on the Mac itself.

Do not turn Internet Sharing on. If macOS asks whether Terminal may access the local network, allow it for this task. Do not disable your firewall globally as a first troubleshooting step; see `guides/RECOVERY-AND-TROUBLESHOOTING.md`.

For sleep prevention, you can run `caffeinate -i` in a spare Terminal window; Ctrl-C ends it. Keep the lid open.

## Folder contents

- `firmware/`: all four official images, original versioned filenames, pinned checksums.
- `tftp/`: identical recovery image with the exact **unversioned** name U-Boot requests.
- `optional-ssh-unlock/`: community configuration and a mandatory warning; not OpenWrt firmware.
- `guides/`: flashing, recovery, first boot and verification.
- `backups/`: initially empty; YOUR device's backups go here when you run helper 03.
- `sources/`: original checksum/signature files, profile metadata, provenance and source links.
- `scripts/`, `config/`: readable helper implementation and isolated SSH/TFTP settings.
- `state/`: local helper bookkeeping and SSH host keys; no router credentials are saved by the helpers.

Backups can contain secrets. If Desktop is synced by iCloud, these backups may sync too. Decide whether that is acceptable before running helper 03; use an encrypted private copy. Folder permissions do not prevent iCloud sync. Never upload Factory/full-flash backups to a group or substitute somebody else's.

## Scope and confidence

The downloaded firmware checksums and local Mac prerequisites were checked. Scripts were syntax-checked and their stock-layout guard tested offline. No live router, adapter, TFTP service or actual flashing was tested during preparation. The start helper performs a local TFTP test when YOU run it; that is still not proof of router-side connectivity. See `TEST-RESULTS.md` for exact checks.

If any command fails, prints an unexpected partition name, or contradicts your device: STOP, keep the full output, and ask for review. Do not substitute `-F`, force-write options, different firmware, or repeated erases to push through an error.
