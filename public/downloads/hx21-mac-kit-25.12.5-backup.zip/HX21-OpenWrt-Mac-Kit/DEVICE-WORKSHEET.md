# Private worksheet — fill in locally; never upload

- Model and revision:
- Stock firmware:
- Original sticker / WAN / LAN / radio MACs:
- ISP credentials stored privately at:
- Backup before or after SSH config restore:
- Verified backup folder:
- Second private backup location:
- Previous Mac network settings:
- Recovery plan:
