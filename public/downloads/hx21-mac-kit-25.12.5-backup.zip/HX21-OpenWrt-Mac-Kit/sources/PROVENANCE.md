# Firmware provenance and verification

Prepared 2026-09-02. The live official releases index listed 25.12.5 as the newest numbered stable 25.12 release checked during preparation. This kit is deliberately PINNED to it; no script silently switches to a newer release or snapshot. Recheck the Firmware Selector if using the kit substantially later.

## Official assets

Base URL: [OpenWrt 25.12.5 mediatek/filogic](https://downloads.openwrt.org/releases/25.12.5/targets/mediatek/filogic/).

- The four `imou_hx21` images were downloaded directly from that directory over HTTPS.
- Each SHA-256 matched the official `sha256sums` and `profiles.json` records.
- Original filenames are in `firmware/`; the recovery-only copy in `tftp/` is renamed as required by HX21 U-Boot and compared byte for byte.
- `sha256sums`, `sha256sums.asc`, `sha256sums.sig`, and `profiles.json` here are the downloaded upstream records, not rewritten summaries.
- The target profile declares supported device `imou,hx21`. No LC-HX3001, Cudy, snapshot or ImmortalWrt image is included.
- The optional kmod is described separately in `optional-bl2/README.md`.

## What was and was not verified

Image integrity against official HTTPS checksum/profile metadata: **PASS**.
Detached GPG signature validation: **NOT PERFORMED**, because GnuPG was not installed on this Mac. Do not interpret checksum success as proof that the signature was verified. Nothing was installed globally to add GnuPG.

For stronger publisher authentication, follow [OpenWrt release signing](https://openwrt.org/docs/guide-user/security/release_signatures) and independently compare the [published signing fingerprint](https://openwrt.org/docs/guide-user/security/signatures). The downloaded key is from the [official keyring](https://git.openwrt.org/keyring/plain/gpg/0x1D53D1877742E911.asc).

Expected primary fingerprint:

```text
92C5 61DE 55AE 6552 F3C7 36B8 2B01 5109 0606 D1D9
```

If YOU choose to install GnuPG (for example `brew install gnupg` if you already use Homebrew), a private kit-local check is:

```sh
cd ~/Desktop/HX21-OpenWrt-Mac-Kit
mkdir -p state/gnupg
chmod 700 state/gnupg
gpg --homedir state/gnupg --show-keys --with-fingerprint sources/openwrt-build-system-nitrokey3.asc
```

Compare the full fingerprint to the independently accessed official page. Only if it matches:

```sh
gpg --homedir state/gnupg --import sources/openwrt-build-system-nitrokey3.asc
gpg --homedir state/gnupg --with-fingerprint --verify sources/sha256sums.asc sources/sha256sums
```

Require a good signature from the expected key. A warning that the key is not personally certified is different from a BAD signature; the independently checked fingerprint is the trust anchor. Then rerun helper 01. If verification fails, stop and investigate, never override it.

## Community payload provenance

The optional SSH configuration was downloaded from a commit-pinned GitHub URL, not a group attachment or a paid helper:
[HX21-ssh.bin at 794117a](https://github.com/byjahidul/Imou-HX21/blob/794117a14c7d563da5defbbb8cd005266e78769e/HX21-ssh.bin).

Its checksum identifies the downloaded copy only. Its contents were not executed or applied. The MAC/Factory report is preserved in its warning file and the payload is segregated from official firmware.

## Research and implementation references

- [Official HX21 instructions and recovery](https://openwrt.org/toh/imou/hx21) — page opening hit bot protection, but the indexed official page contents were available for cross-checking; no challenge was bypassed.
- [Official device hardware data](https://openwrt.org/toh/hwdata/imou/imou_hx21).
- [Upstream HX21 support commit](https://lists.infradead.org/pipermail/lede-commits/2025-November/028095.html).
- [HX21 U-Boot patch at v25.12.5](https://github.com/openwrt/openwrt/blob/v25.12.5/package/boot/uboot-mediatek/patches/466-add-imou-hx21.patch) — filename, TFTP IP, bootmenu and boot flow cross-checked against the release source.
- [OpenWrt firmware selector](https://firmware-selector.openwrt.org/?version=25.12.5&target=mediatek%2Ffilogic&id=imou_hx21).
- [Official APK documentation](https://openwrt.org/docs/guide-user/additional-software/apk).
- [Community repository](https://github.com/itachi-re/imou-hx21-openwrt) and [guide](https://github.com/itachi-re/imou-hx21-openwrt/blob/main/docs/installation-guide.md) — context, not a substitute for device matching.
- [Group walkthrough](https://www.facebook.com/groups/383628147262547/permalink/1192441733047847/).
- [Group MAC warning / repository discussion](https://www.facebook.com/groups/383628147262547/permalink/1209221474703206/).
- [Unpublished permanent-MAC-fix claim](https://www.facebook.com/groups/383628147262547/permalink/1215483640743656/).
- [Owner success report](https://www.facebook.com/groups/383628147262547/permalink/1205296418429045/).
- Mac server implementation checked against this Mac's `man tftpd`, `man tftp`, `man launchd.plist`, and `/System/Library/LaunchDaemons/tftp.plist`.

The folder contains original task-specific explanations/helpers, public firmware and upstream metadata. It does not archive all Facebook content, include other people's private backups or supply a guaranteed stock image for your individual router.
