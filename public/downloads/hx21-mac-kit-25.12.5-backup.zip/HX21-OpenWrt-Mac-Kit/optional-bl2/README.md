# Optional BL2 write-unlock module — not part of normal first boot

Only for the optional section of `guides/FLASHING-MAC.md`. Skip if BL2 was already updated successfully. Do not load this just because it is included.

Bundled official package:
`kmod-mtd-rw-6.12.94.2021.02.28~e8776739-r1.apk`

Source directory:
[25.12.5 mediatek/filogic kernel modules](https://downloads.openwrt.org/releases/25.12.5/targets/mediatek/filogic/kmods/6.12.94-1-5a6c1f71be683ae9980b15d3ce73e24d/)

The download was obtained over HTTPS. Its recorded local SHA-256 is in `../sources/EXTRA-FILES-SHA256.txt`; that is a transport/storage record, not an independently published package checksum. The router's package manager must accept its signature and exact kernel dependency normally. Never use `--allow-untrusted` or a dependency-forcing flag.

Prefer the normal online install (`apk update && apk add kmod-mtd-rw`) once Internet works. For an offline attempt with the exact bundled 25.12.5 image, run on MAC from the kit:

```sh
scp -O -F config/ssh-config 'optional-bl2/kmod-mtd-rw-6.12.94.2021.02.28~e8776739-r1.apk' hx21-openwrt:/tmp/hx21-mtd-rw.apk
ssh -F config/ssh-config hx21-openwrt
```

On ROUTER:

```sh
uname -r
apk add /tmp/hx21-mtd-rw.apk
```

Require kernel `6.12.94` AND the package manager's full kernel-ABI/dependency/signature checks to pass. A matching `uname` string alone is insufficient. If offline metadata/dependencies prevent installation, stop and use the normal configured repositories when online; do not bypass verification. Continue to the main guide's checksum/partition checks only after a successful package install.
