#!/bin/bash
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$KIT_DIR/scripts/start-tftp.sh"
result=$?
printf '\nFinished with exit code %s (0 = success). Press Enter to close. ' "$result"
read -r answer
exit "$result"
