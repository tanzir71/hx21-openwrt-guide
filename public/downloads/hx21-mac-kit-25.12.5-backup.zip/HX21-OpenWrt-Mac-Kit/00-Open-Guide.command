#!/bin/bash
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
open -a TextEdit "$KIT_DIR/START-HERE.md"
