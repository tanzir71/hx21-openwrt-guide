#!/bin/bash
set -euo pipefail
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
fail() { printf '\nSTOP: %s\n' "$*" >&2; exit 1; }
confirm() {
  local answer
  printf '\n%s\nType %s to continue: ' "$1" "$2"
  read -r answer
  [ "$answer" = "$2" ] || fail 'Cancelled; confirmation did not match.'
}
require_mac() { [ "$(uname -s)" = Darwin ] || fail 'These helpers are for macOS.'; }
verify_firmware() {
  (cd "$KIT_DIR/firmware" && shasum -a 256 -c SHA256SUMS-HX21.txt) || fail 'Firmware checksum failure.'
  local expected file published
  while read -r expected file; do
    published="$(awk -v wanted="$file" '{n=$2; sub(/^\*/, "", n); if(n==wanted) print $1}' "$KIT_DIR/sources/sha256sums")"
    [ "$published" = "$expected" ] || fail "Official checksum record disagrees: $file"
  done < "$KIT_DIR/firmware/SHA256SUMS-HX21.txt"
  cmp "$KIT_DIR/firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-initramfs-recovery.itb" "$KIT_DIR/tftp/openwrt-mediatek-filogic-imou_hx21-initramfs-recovery.itb" || fail 'TFTP image differs from the verified recovery image.'
}
recovery_interface() {
  ifconfig -a | awk '/^[[:alnum:]][^ ]*:/ {i=$1; sub(/:$/, "", i)} $1=="inet" && $2=="192.168.1.254" {print i}'
}
require_ethernet() {
  local iface="$1" port
  [[ "$iface" =~ ^en[0-9]+$ ]] || fail 'Could not identify a single enN network interface.'
  port="$(networksetup -listallhardwareports | awk -v dev="$iface" '/^Hardware Port:/ {p=$0} $1=="Device:" && $2==dev {print p}')"
  [ -n "$port" ] || fail 'Interface not found in networksetup.'
  case "$port" in *Wi-Fi*|*AirPort*) fail 'This is Wi-Fi. Use wired Ethernet.' ;; esac
  printf '%s (%s)\n' "$port" "$iface"
}
