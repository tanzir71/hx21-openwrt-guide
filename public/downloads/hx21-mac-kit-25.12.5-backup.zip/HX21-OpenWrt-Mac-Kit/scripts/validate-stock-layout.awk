# Deliberately restrictive: this is the documented STOCK HX21 map, not OpenWrt.
BEGIN {
  label["mtd0:"]="spi0.0"; size["mtd0:"]="08000000"
  label["mtd1:"]="BL2"; size["mtd1:"]="00100000"
  label["mtd2:"]="u-boot-env"; size["mtd2:"]="00080000"
  label["mtd3:"]="Factory"; size["mtd3:"]="00200000"
  label["mtd4:"]="FIP"; size["mtd4:"]="00200000"
  label["mtd5:"]="ubi"; size["mtd5:"]="07280000"
}
NR==1 { if ($1 != "dev:") bad=1; next }
NF {
  n=$4; gsub(/"/, "", n)
  if (NF!=4 || !($1 in label) || label[$1]!=n || tolower($2)!=size[$1] || seen[$1]++) bad=1
  else { d=$1; sub(/:$/, "", d); print d, $2, n }
  count++
}
END { if (count!=6 || bad) exit 1 }
