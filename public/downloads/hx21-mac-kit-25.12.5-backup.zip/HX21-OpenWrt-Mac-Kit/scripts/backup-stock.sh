#!/bin/bash
# Reads flash over SSH into Mac files. No remote flash writes, reboot, or erase.
source "$(dirname "$0")/common.sh"
require_mac
verify_firmware
printf '\nThis connects to stock HX21 at 192.168.10.1 as root. It does NOT unlock SSH.\n'
printf 'If you already used the SSH config payload, these are POST-UNLOCK backups.\n'
printf 'Backups may include passwords and unique calibration data. Keep them private.\n'
confirm 'Confirm the isolated wired device is your Imou HX21, still running STOCK firmware.' BACKUP
mkdir -p "$KIT_DIR/backups" "$KIT_DIR/state"
chmod 700 "$KIT_DIR/backups" "$KIT_DIR/state"
BACKUP_DIR="$(mktemp -d "$KIT_DIR/backups/stock-$(date +%Y%m%d-%H%M%S).XXXXXX")"
SSH_TEMP="$(mktemp -d /private/tmp/hx21-ssh.XXXXXX)"
SSH_ARGS=(-F "$KIT_DIR/config/ssh-config" -o "ControlPath=$SSH_TEMP/control" -o ControlMaster=auto -o ControlPersist=60)
cleanup() { ssh "${SSH_ARGS[@]}" -O exit hx21-stock >/dev/null 2>&1 || true; }
trap cleanup EXIT
ssh "${SSH_ARGS[@]}" -M -N -f hx21-stock || fail 'SSH failed. No backup completed.'
remote() { ssh "${SSH_ARGS[@]}" -n -T hx21-stock "$1"; }
remote 'cat /proc/mtd' > "$BACKUP_DIR/proc-mtd.txt"
printf '\nReported partition layout:\n'
cat "$BACKUP_DIR/proc-mtd.txt"
awk -f "$KIT_DIR/scripts/validate-stock-layout.awk" "$BACKUP_DIR/proc-mtd.txt" > "$BACKUP_DIR/partition-list.txt" || fail "Unexpected stock layout. STOP and ask for review. Saved: $BACKUP_DIR"
remote 'command -v md5sum >/dev/null' || fail 'Router md5sum is unavailable; cannot compare readback integrity.'
remote 'uname -a; cat /etc/openwrt_release 2>/dev/null; cat /tmp/sysinfo/model 2>/dev/null; ip link 2>/dev/null; true' > "$BACKUP_DIR/device-info.txt"
remote 'dmesg' > "$BACKUP_DIR/dmesg-before.txt" || true
printf 'Created: %s\nUnlock method (fill in):\nOriginal MACs recorded in DEVICE-WORKSHEET.md: yes/no\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$BACKUP_DIR/NOTES.txt"
available_kb="$(df -Pk "$BACKUP_DIR" | awk 'END {print $4}')"
[ "$available_kb" -ge 1048576 ] || fail 'Need at least 1 GiB free on the backup volume.'
all_matched=1
while read -r dev hex label; do
  [[ "$dev" =~ ^mtd[0-9]+$ ]] || fail 'Invalid MTD identifier.'
  expected_bytes=$((16#$hex))
  file="${dev}_${label}.bin"
  printf '\nBacking up %s (%s bytes) directly to this Mac...\n' "$file" "$expected_bytes"
  remote "cat /dev/$dev" > "$BACKUP_DIR/$file.partial" || fail "Read failed: $dev. Partial file retained; do NOT flash."
  actual_bytes="$(stat -f %z "$BACKUP_DIR/$file.partial")"
  [ "$actual_bytes" = "$expected_bytes" ] || fail "Wrong size for $dev: got $actual_bytes; expected $expected_bytes."
  mv "$BACKUP_DIR/$file.partial" "$BACKUP_DIR/$file"
  router_md5="$(remote "md5sum /dev/$dev" | awk 'NR==1 {print $1}')"
  local_md5="$(md5 -q "$BACKUP_DIR/$file")"
  if [[ "$router_md5" =~ ^[[:xdigit:]]{32}$ ]] && [ "$router_md5" = "$local_md5" ]; then
    printf '%s: SIZE + READBACK MATCH\n' "$file" | tee -a "$BACKUP_DIR/validation.txt"
  else
    printf '%s: READBACK MISMATCH (router=%s Mac=%s)\n' "$file" "$router_md5" "$local_md5" | tee -a "$BACKUP_DIR/validation.txt"
    all_matched=0
  fi
done < "$BACKUP_DIR/partition-list.txt"
(cd "$BACKUP_DIR" && shasum -a 256 ./*.bin > SHA256SUMS.txt)
remote 'dmesg' > "$BACKUP_DIR/dmesg-after.txt" || true
if [ "$all_matched" -ne 1 ]; then
  fail "At least one readback differed. Live UBI/full-flash can change, but this is NOT a verified restore set. Do not flash. Keep the files and ask for review: $BACKUP_DIR"
fi
printf 'All six exact byte counts and same-device MD5 readbacks matched.\nThis is NOT a guarantee of NAND restore compatibility or pre-unlock calibration.\n' > "$BACKUP_DIR/BACKUP-COMPLETE.txt"
printf '\nBACKUP COMPLETE: %s\nCopy this whole folder to a second private storage location before flashing.\n' "$BACKUP_DIR"
