#!/bin/bash
source "$(dirname "$0")/common.sh"
require_mac
verify_firmware
(cd "$KIT_DIR" && shasum -a 256 -c sources/EXTRA-FILES-SHA256.txt) || fail 'Extra asset hash changed.'
printf '\nOfficial HTTPS checksum records match all four images. TFTP copy matches.\n'
printf 'GPG signature verification has NOT been performed; see sources/PROVENANCE.md.\n'
for binary in /usr/bin/ssh /usr/bin/scp /usr/bin/shasum /sbin/md5 /usr/bin/tftp /usr/libexec/tftpd /bin/launchctl /usr/libexec/PlistBuddy; do
  [ -x "$binary" ] || fail "Required Mac tool missing: $binary"
done
plutil -lint "$KIT_DIR/config/tftp-template.plist"
printf '\nMac tools found. No router contacted; no network settings changed.\n'
