#!/bin/bash
source "$(dirname "$0")/common.sh"
require_mac
printf 'First set your wired Ethernet IPv4 MANUALLY to 192.168.1.254 / 255.255.255.0 in System Settings.\n'
printf 'Unplug router WAN; turn Mac Wi-Fi, VPN and Internet Sharing off.\n'
HX21_IFACE="$(recovery_interface)"
require_ethernet "$HX21_IFACE"
if ifconfig -a | awk '$1=="inet" && $2=="192.168.10.2" {found=1} END {exit !found}'; then
  fail '192.168.10.2 already exists. Do not add a duplicate alias; check the guide/state folder.'
fi
confirm "Add temporary stock-access address 192.168.10.2/24 to $HX21_IFACE? This changes only this Mac, not the router." ADD
sudo /sbin/ifconfig "$HX21_IFACE" alias 192.168.10.2 netmask 255.255.255.0
mkdir -p "$KIT_DIR/state"
printf '%s\n' "$HX21_IFACE" > "$KIT_DIR/state/stock-alias-interface"
printf '\nMac can now reach stock 192.168.10.1 and serve recovery from 192.168.1.254.\n'
printf 'Run the cleanup helper at the end, then restore your previous Ethernet IPv4 settings.\n'
