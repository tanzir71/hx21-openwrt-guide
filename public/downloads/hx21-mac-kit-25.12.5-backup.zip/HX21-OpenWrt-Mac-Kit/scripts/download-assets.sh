#!/bin/bash
# Only downloads files to this kit; never connects to a router or runs a download.
set -euo pipefail
KIT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BASE_URL='https://downloads.openwrt.org/releases/25.12.5/targets/mediatek/filogic'
mkdir -p "$KIT_DIR/sources" "$KIT_DIR/tftp" "$KIT_DIR/optional-ssh-unlock" "$KIT_DIR/optional-bl2" "$KIT_DIR/backups" "$KIT_DIR/state"
chmod 700 "$KIT_DIR" "$KIT_DIR/backups" "$KIT_DIR/state"
fetch() {
  local url="$1" dest="$2"
  if [ -e "$dest" ]; then
    printf 'Already present; leaving unchanged: %s\n' "$dest"
    return
  fi
  /usr/bin/curl --proto '=https' --tlsv1.2 --fail --location --show-error --silent --retry 2 --connect-timeout 15 --max-time 300 "$url" -o "$dest.partial"
  mv "$dest.partial" "$dest"
}
while read -r expected file; do
  fetch "$BASE_URL/$file" "$KIT_DIR/firmware/$file"
done < "$KIT_DIR/firmware/SHA256SUMS-HX21.txt"
for file in sha256sums sha256sums.asc sha256sums.sig profiles.json; do
  fetch "$BASE_URL/$file" "$KIT_DIR/sources/$file"
done
(cd "$KIT_DIR/firmware" && /usr/bin/shasum -a 256 -c SHA256SUMS-HX21.txt)
recovery='openwrt-mediatek-filogic-imou_hx21-initramfs-recovery.itb'
if [ ! -e "$KIT_DIR/tftp/$recovery" ]; then
  cp "$KIT_DIR/firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-initramfs-recovery.itb" "$KIT_DIR/tftp/$recovery"
fi
/usr/bin/cmp "$KIT_DIR/firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-initramfs-recovery.itb" "$KIT_DIR/tftp/$recovery"
fetch 'https://raw.githubusercontent.com/byjahidul/Imou-HX21/794117a14c7d563da5defbbb8cd005266e78769e/HX21-ssh.bin' "$KIT_DIR/optional-ssh-unlock/HX21-ssh.bin"
fetch 'https://git.openwrt.org/keyring/plain/gpg/0x1D53D1877742E911.asc' "$KIT_DIR/sources/openwrt-build-system-nitrokey3.asc"
fetch "$BASE_URL/kmods/6.12.94-1-5a6c1f71be683ae9980b15d3ce73e24d/kmod-mtd-rw-6.12.94.2021.02.28~e8776739-r1.apk" "$KIT_DIR/optional-bl2/kmod-mtd-rw-6.12.94.2021.02.28~e8776739-r1.apk"
printf '\nFiles downloaded. The community SSH payload is OPTIONAL and not safety-certified.\n'
printf 'Read START-HERE.md before restoring any config or changing the router.\n'
