#!/bin/bash
# Offline tests only: no router, network service or sudo calls.
set -euo pipefail
KIT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$KIT_DIR"
for hx21_script in scripts/*.sh ./*.command; do
  /bin/bash -n "$hx21_script"
done
printf 'PASS: every shell script parses under macOS Bash.\n'
/bin/bash scripts/verify-files.sh
fixture() {
  printf '%s\n' 'dev: size erasesize name' \
    'mtd0: 08000000 00020000 "spi0.0"' \
    'mtd1: 00100000 00020000 "BL2"' \
    'mtd2: 00080000 00020000 "u-boot-env"' \
    'mtd3: 00200000 00020000 "Factory"' \
    'mtd4: 00200000 00020000 "FIP"' \
    'mtd5: 07280000 00020000 "ubi"'
}
fixture | awk -f scripts/validate-stock-layout.awk >/dev/null
printf 'PASS: documented stock map accepted.\n'
if fixture | sed 's/"Factory"/"factory"/' | awk -f scripts/validate-stock-layout.awk >/dev/null; then exit 1; fi
printf 'PASS: changed Factory label rejected.\n'
if fixture | sed 's/07280000/07a80000/' | awk -f scripts/validate-stock-layout.awk >/dev/null; then exit 1; fi
printf 'PASS: changed UBI size rejected.\n'
if fixture | sed '/mtd4:/d' | awk -f scripts/validate-stock-layout.awk >/dev/null; then exit 1; fi
printf 'PASS: missing partition rejected.\n'
if { fixture; printf '%s\n' 'mtd9: 00100000 00020000 "unknown"'; } | awk -f scripts/validate-stock-layout.awk >/dev/null; then exit 1; fi
printf 'PASS: extra/unknown partition rejected.\n'
if { fixture; printf '%s\n' 'mtd1: 00100000 00020000 "BL2"'; } | awk -f scripts/validate-stock-layout.awk >/dev/null; then exit 1; fi
printf 'PASS: duplicate partition rejected.\n'
for stage in hx21-stock hx21-recovery hx21-openwrt; do
  ssh -G -F config/ssh-config "$stage" >/dev/null
done
printf 'PASS: all three isolated SSH configs parse without connecting.\n'
printf 'Offline checks complete. Live backup, TFTP service and flashing remain UNTESTED.\n'
