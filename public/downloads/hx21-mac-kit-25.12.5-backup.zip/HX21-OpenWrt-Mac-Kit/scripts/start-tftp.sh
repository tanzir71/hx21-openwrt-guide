#!/bin/bash
source "$(dirname "$0")/common.sh"
require_mac
verify_firmware
HX21_IFACE="$(recovery_interface)"
require_ethernet "$HX21_IFACE"
printf '\nServes ONLY the public recovery image, bound to 192.168.1.254 UDP/69.\n'
printf 'Keep Wi-Fi, VPN and Internet Sharing off; connect only Mac Ethernet to HX21 LAN.\n'
confirm 'Start a temporary macOS TFTP service? Admin password required. No router command is sent.' START
sudo -v
if sudo launchctl print system/local.hx21.openwrt.tftpd >/dev/null 2>&1; then
  fail 'Kit TFTP service already loaded. Run the stop helper before restarting.'
fi
if sudo lsof -nP -iUDP:69 2>/dev/null | awk 'NR>1 {busy=1} END {exit !busy}'; then
  fail 'UDP/69 is already occupied. Existing service left unchanged.'
fi
TFTP_SESSION="$(mktemp -d /private/tmp/hx21-tftp.XXXXXX)"
mkdir "$TFTP_SESSION/root"
RECOVERY='openwrt-mediatek-filogic-imou_hx21-initramfs-recovery.itb'
cp "$KIT_DIR/tftp/$RECOVERY" "$TFTP_SESSION/root/$RECOVERY"
cp "$KIT_DIR/config/tftp-template.plist" "$TFTP_SESSION/service.plist"
/usr/libexec/PlistBuddy -c "Set :ProgramArguments:3 $TFTP_SESSION/root" "$TFTP_SESSION/service.plist"
plutil -lint "$TFTP_SESSION/service.plist"
chmod 755 "$TFTP_SESSION" "$TFTP_SESSION/root"
chmod 644 "$TFTP_SESSION/service.plist" "$TFTP_SESSION/root/$RECOVERY"
sudo chown root:wheel "$TFTP_SESSION" "$TFTP_SESSION/root" "$TFTP_SESSION/service.plist" "$TFTP_SESSION/root/$RECOVERY"
sudo launchctl bootstrap system "$TFTP_SESSION/service.plist" || fail "TFTP could not start. Staging retained at $TFTP_SESSION. No firmware was flashed."
mkdir -p "$KIT_DIR/state"
printf '%s\n' "$TFTP_SESSION" > "$KIT_DIR/state/tftp-session.txt"
TFTP_TEST="$(mktemp -d /private/tmp/hx21-tftp-test.XXXXXX)"
printf 'binary\nrexmt 1\ntimeout 10\nget %s %s/recovery.itb\nquit\n' "$RECOVERY" "$TFTP_TEST" | tftp 192.168.1.254
if ! cmp "$KIT_DIR/tftp/$RECOVERY" "$TFTP_TEST/recovery.itb"; then
  sudo launchctl bootout system/local.hx21.openwrt.tftpd || true
  fail 'Local TFTP self-test failed. Service stop attempted. Do not flash; check firewall/network and the guide.'
fi
printf '\nTFTP STARTED; local byte-for-byte transfer test PASSED.\n'
printf 'This does not prove the router can reach it through the Ethernet/firewall path.\n'
printf 'Leave this service running throughout flashing. Run the stop helper when finished.\n'
printf 'Staging: %s (public firmware only; retained for troubleshooting).\n' "$TFTP_SESSION"
