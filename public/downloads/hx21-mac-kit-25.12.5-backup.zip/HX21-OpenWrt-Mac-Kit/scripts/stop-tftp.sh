#!/bin/bash
source "$(dirname "$0")/common.sh"
require_mac
confirm 'Finished flashing/recovery? Stop ONLY the kit TFTP service and remove ONLY its recorded stock IP alias.' STOP
sudo -v
if sudo launchctl print system/local.hx21.openwrt.tftpd >/dev/null 2>&1; then
  sudo launchctl bootout system/local.hx21.openwrt.tftpd
  printf 'Kit TFTP service stopped. Apple/other TFTP services were not changed.\n'
else
  printf 'Kit TFTP service is not loaded.\n'
fi
if [ -f "$KIT_DIR/state/stock-alias-interface" ]; then
  HX21_IFACE="$(< "$KIT_DIR/state/stock-alias-interface")"
  [[ "$HX21_IFACE" =~ ^en[0-9]+$ ]] || fail 'Invalid saved interface; remove alias manually after checking.'
  if ifconfig "$HX21_IFACE" | awk '$1=="inet" && $2=="192.168.10.2" {found=1} END {exit !found}'; then
    sudo ifconfig "$HX21_IFACE" -alias 192.168.10.2
    printf 'Removed 192.168.10.2 alias from %s.\n' "$HX21_IFACE"
  fi
  mv "$KIT_DIR/state/stock-alias-interface" "$KIT_DIR/state/stock-alias-interface.stopped-$(date +%Y%m%d-%H%M%S)"
fi
printf '\nRestore Ethernet IPv4 to your PREVIOUS setting in System Settings (normally DHCP).\n'
printf 'Re-enable Wi-Fi/VPN only after the recovery process has ended.\n'
printf 'Temporary public TFTP files are retained in /private/tmp; no backups were removed.\n'
