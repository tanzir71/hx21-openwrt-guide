# First boot and acceptance checks

Use the wired LAN connection until finished. Installed UI: `http://192.168.1.1`.

1. Confirm `ubus call system board` reports `imou,hx21` and release 25.12.5. Set the root password (`passwd` or LuCI System → Administration).
2. Compare current WAN/LAN/radio MACs with your pre-flash worksheet. If changed, preserve evidence. An interface-level WAN MAC override can satisfy an ISP binding, but is NOT proof that Factory calibration or the original stored MAC has been restored. Do not edit raw Factory/NVRAM casually.
3. Configure WAN according to your ISP: DHCP, PPPoE credentials or static settings; apply the ISP's VLAN only if actually required. Reconnect WAN after basic admin security is in place. If upstream also uses `192.168.1.0/24`, resolve that subnet overlap before connecting it.
4. Enable/configure both Wi-Fi radios in LuCI Network → Wireless. Initial radio disablement is normal. Set your actual country (BD if operating in Bangladesh), SSID and a strong password. Choose WPA2/WPA3 settings appropriate for your clients. Do not force unsupported channels or power values. DFS channel availability can delay 5 GHz startup.
5. Verify LAN DHCP, local management, DNS and Internet from a client; check both bands, wired link rate and expected ISP speed. Compare range/latency at the same locations and channels as stock. AX3000 is not guaranteed application throughput or range.
6. Reboot normally with the stock-install steps completed. Once healthy, stop TFTP, restore Mac Ethernet settings and confirm the router boots from its own flash without the recovery server.
7. Export a fresh OpenWrt configuration backup from LuCI. Keep it separate from the original STOCK NAND backups.

Baseline diagnostics (on installed router):

```sh
ubus call system board
ip link
ubus call network.interface.wan status
wifi status
df -h
free
logread | tail -n 80
```

Do not post outputs containing PPPoE credentials, public IPs, serials or other private values without reviewing/redacting them.

## Optional packages come later

First get a clean baseline. OpenWrt 25.12+ uses `apk update` and `apk add PACKAGE`. Do not blindly mass-run `apk upgrade`; use coherent firmware upgrades/Attended Sysupgrade for routine system updates. See [official package guidance](https://openwrt.org/docs/guide-user/additional-software/apk).

SQM/CAKE may help loaded latency, not create extra bandwidth. VPNs, filtering, mesh and monitoring need their own configuration and have CPU/RAM tradeoffs. No personalized Wi-Fi password, ISP credentials, country override, SQM rate or VPN settings have been invented or installed for you.
