# First installation from STOCK — Mac checklist

Read `START-HERE.md` first. Do not paste this entire document into Terminal.
**MAC** blocks run in macOS Terminal. **ROUTER** blocks run only after SSH login.
`exit` leaves the router shell and returns you to the Mac.

This checklist adapts the [official HX21 device procedure](https://openwrt.org/toh/imou/hx21) to macOS. It follows the documented FIP/BL2 → UBI erase → TFTP recovery → sysupgrade route. That UBI erase is intentional and destructive; reset-button recovery is a separate recovery route, not permission to skip prerequisites.

## A. Physical preparation and stock access

Complete the worksheet and Mac dual-address setup in START-HERE. Mac Ethernet must have `192.168.1.254/24` plus helper 02's `192.168.10.2/24`. Router WAN disconnected, Mac Wi-Fi/VPN off, Ethernet into a router LAN port.

MAC — open Terminal and enter the folder:

```sh
cd ~/Desktop/HX21-OpenWrt-Mac-Kit
ssh -F config/ssh-config hx21-stock
```

First contact asks about a host key. Accept only when your cable/isolation confirms this is your router; compare an independently available fingerprint if you have one. Use your root password if set. After the documented SSH unlock, the password is normally blank (press Enter). Stock SSH may already be enabled on some units; check before restoring a modified configuration.

If SSH is refused, do not keep retrying or flash via the stock firmware-upgrade page. Read `optional-ssh-unlock/READ-BEFORE-USING.md`, then choose the config or UART route. If stock LAN IP is not `192.168.10.1`, stop and adapt the network and SSH configuration together; these helpers are intentionally not guessing.

ROUTER — inspect, then exit:

```sh
cat /proc/mtd
exit
```

## B. Back up before any write

Run `03-Backup-Stock.command` from Finder, or on the MAC:

```sh
/bin/bash scripts/backup-stock.sh
```

This streams all six documented MTD devices directly to the Mac, validates each size, compares each file to a second device read using MD5, and records local SHA-256 hashes. It uses no Windows loop and does not fill router `/tmp` with a whole NAND dump.

Require `BACKUP-COMPLETE.txt`. Copy the entire backup set to another private destination. Record which set in the worksheet. A partial/mismatched read is a STOP, even if UBI changing while mounted could explain it. Matching reads are not a guarantee of cross-partition snapshot consistency or restore compatibility. The full-flash dump includes no separate NAND OOB/bad-block metadata.

Expected stock layout (helper refuses any difference):

| Device | Label | Bytes |
|---|---|---:|
| mtd0 | spi0.0, whole flash | 134217728 |
| mtd1 | BL2 | 1048576 |
| mtd2 | u-boot-env | 524288 |
| mtd3 | Factory | 2097152 |
| mtd4 | FIP | 2097152 |
| mtd5 | ubi | 120061952 |

Do not reuse these numbers on OpenWrt: its partition names/indexes/layout differ. A web configuration export is useful but is not a flash/Factory backup.

## C. Start the Mac TFTP service BEFORE replacing the bootloader

Run `04-Start-TFTP.command`. Require `TFTP STARTED; local byte-for-byte transfer test PASSED`.

The helper stages one verified public recovery file in an isolated temporary directory and loads a temporary, non-login-persistent launchd service. It binds `192.168.1.254:69`, does not alter Apple's existing TFTP service, and does not expose this kit or backups. Closing its Terminal window after success does not stop the loaded service.

Exact requested filename, already prepared in `tftp/`:

```text
openwrt-mediatek-filogic-imou_hx21-initramfs-recovery.itb
```

Do not serve a sysupgrade, FIP or preloader under that name. Keep TFTP running throughout the following steps. Its local self-test checks server setup, not the router's Ethernet path.

## D. Upload and verify the two bootloader components

MAC:

```sh
cd ~/Desktop/HX21-OpenWrt-Mac-Kit
/bin/bash scripts/verify-files.sh
scp -O -F config/ssh-config firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-bl31-uboot.fip hx21-stock:/tmp/hx21-fip.bin
scp -O -F config/ssh-config firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-preloader.bin hx21-stock:/tmp/hx21-preloader.bin
md5 -q firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-bl31-uboot.fip
md5 -q firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-preloader.bin
ssh -F config/ssh-config hx21-stock
```

`scp -O` selects legacy SCP; stock firmware may not have an SFTP subsystem. The two local MD5 values above are transport checks, not authenticity checks; official-image SHA-256 verification happened first.

ROUTER:

```sh
md5sum /tmp/hx21-fip.bin /tmp/hx21-preloader.bin
cat /proc/mtd
```

Compare both remote hashes exactly to the two Mac hashes in the same order. Stop on mismatch, wrong label, truncated transfer or a failed backup. Check every final go/no-go box in the worksheet now.

## E. DESTRUCTIVE: replace bootloader and remove stock UBI

From this point stock rollback is a recovery operation, not a normal web downgrade. Do not disconnect power while a write/erase is running.

ROUTER — write FIP, then check the result before proceeding:

```sh
mtd write /tmp/hx21-fip.bin FIP && sync
```

Require a successful completed write, with no erase/write/I/O error. If this fails, stop immediately; do not reboot casually, erase UBI or try another file. Preserve the output and obtain recovery advice while the shell is still available.

ROUTER — the device wiki also writes BL2 on stock:

```sh
mtd write /tmp/hx21-preloader.bin BL2 && sync
```

If it succeeds, do not rewrite BL2 later. If the ONLY failure is that stock BL2 is write-protected and nothing was erased/written, the wiki permits deferring this step; see optional BL2 notes below. A partial write, I/O error, unknown partition, wrong size or ambiguous failure is NOT the same situation: stop and ask for review.

Before the next command, confirm again that TFTP is running on the Mac and that your private backup copies exist. This removes the stock OS/configuration in UBI.

ROUTER — **erases stock UBI and reboots**:

```sh
mtd erase ubi && sync && reboot
```

The SSH connection will drop. Keep the Mac link, both addresses, power and TFTP unchanged. Allow several minutes for bootloader initialization/recovery. The new bootloader fetches the recovery image and boots OpenWrt; initialization may also create/rewrite NAND volumes. This is not a promise that TFTP only touches RAM.

## F. Recovery OpenWrt → permanent installation

MAC — once recovery responds at `192.168.1.1`:

```sh
ssh -F config/ssh-config hx21-recovery
```

ROUTER — inspect identity and environment:

```sh
ubus call system board
cat /proc/mtd
mount
```

Require `board_name` = `imou,hx21` and OpenWrt recovery, not the stock UI or a different router. If unsure whether you booted the expected image, stop. Leave the shell:

```sh
exit
```

MAC:

```sh
scp -O -F config/ssh-config firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-squashfs-sysupgrade.itb hx21-recovery:/tmp/hx21-sysupgrade.itb
ssh -F config/ssh-config hx21-recovery
```

ROUTER — verify SHA-256. It must equal `4e6dff2db0ae3e497b1d82f534458d9240ac989c67365ba4082811a47123a247`:

```sh
sha256sum /tmp/hx21-sysupgrade.itb
sysupgrade -T /tmp/hx21-sysupgrade.itb
```

Require the image test to succeed. Never add `-F` to override a compatibility rejection.

ROUTER — **permanent install, with clean settings**:

```sh
sysupgrade -n /tmp/hx21-sysupgrade.itb
```

Connection loss is expected. Do not interrupt power. Wait several minutes, then use the installed-stage alias:

MAC:

```sh
ssh -F config/ssh-config hx21-openwrt
```

ROUTER:

```sh
ubus call system board
cat /etc/openwrt_release
passwd
```

Confirm Imou HX21 and version 25.12.5; set a strong new root password. Continue with `guides/FIRST-BOOT.md`. The three SSH aliases intentionally keep stock/recovery/final host keys distinct; never ignore an unexpected key change within the same stage.

## G. Optional BL2 update after OpenWrt

Skip if BL2 was successfully updated in step E. This is a separate high-risk operation, not required for ordinary future upgrades. Only consider it for the documented clean stock-write-protection case and after a stable install, verified backups and a reviewed recovery plan.

On the installed ROUTER with working Internet:

```sh
apk update && apk add kmod-mtd-rw
```

OpenWrt 25.12 uses `apk`, not `opkg`. Do not force-install a module for a different kernel or bypass signature/dependency checks. If offline, see `optional-bl2/README.md` for the matching bundled module.

MAC — copy the already verified preloader:

```sh
scp -O -F config/ssh-config firmware/openwrt-25.12.5-mediatek-filogic-imou_hx21-preloader.bin hx21-openwrt:/tmp/hx21-preloader.bin
ssh -F config/ssh-config hx21-openwrt
```

ROUTER — check SHA-256 equals `ad13725b82566ebd6b6a0cc37b83a0b9f17b8685702f32efc02fefff4126b1fc`, and verify the target label is lowercase `bl2` in your actual map:

```sh
sha256sum /tmp/hx21-preloader.bin
cat /proc/mtd
```

Only after both checks, ROUTER — **DESTRUCTIVE bootloader write**:

```sh
insmod mtd-rw i_want_a_brick=1
mtd write /tmp/hx21-preloader.bin bl2 && sync
```

Require success. Then reboot normally. If the module fails to load or any write fails, stop; do not try to bypass it. Remove `kmod-mtd-rw` after a successful reboot if it is no longer needed. Do not leave flash-write-unlock tooling active for routine use.

## H. Finish

After a successful standalone reboot and LAN/WAN/Wi-Fi tests, run helper 05. Restore the Mac's previous Ethernet IPv4/DNS settings, normally DHCP, then Wi-Fi/VPN as desired. Keep firmware, original backups and the filled worksheet privately. Later compatible upgrades use sysupgrade/Attended Sysupgrade, not this stock bootloader/UBI-erasure procedure.
