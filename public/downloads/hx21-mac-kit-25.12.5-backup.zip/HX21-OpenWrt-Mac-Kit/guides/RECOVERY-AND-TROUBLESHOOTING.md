# Recovery and troubleshooting

If a bootloader write errors, keep power and the working shell if possible; save its exact output and ask for review. Do not repeatedly reboot or erase partitions to experiment.

## Mac/SSH issues

- `Connection refused`: stock SSH may not be unlocked, or firmware has not finished booting. Confirm stock UI and correct IP, not repeated flash attempts.
- `No route`/timeouts: check LAN cable, correct Ethernet adapter, both Mac IPv4 addresses, Wi-Fi/VPN off, no Internet Sharing. `ifconfig` and `route -n get 192.168.10.1` / `route -n get 192.168.1.1` are useful read-only checks.
- SFTP subsystem failure with SCP: use the included `scp -O` syntax.
- A host-key change within a named stage: stop and confirm identity/state. The kit keeps separate stock/recovery/installed aliases. Only after verifying an intentional reflash may you remove that specific alias with `ssh-keygen -R hx21-recovery -f ~/Desktop/HX21-OpenWrt-Mac-Kit/state/known_hosts` (use the actual affected alias). Do not delete all host keys or switch checking off.
- If an old stock SSH server explicitly offers only `ssh-rsa`, a host-scoped `-o HostKeyAlgorithms=+ssh-rsa` may be necessary for that stock connection; review the exact negotiation error first. Do not weaken global SSH defaults or add obsolete ciphers speculatively.
- If macOS blocks a .command file, inspect it, then use `/bin/bash scripts/NAME.sh` from the kit in Terminal. Do not globally disable Gatekeeper. Approve Terminal's local-network permission if requested.

## TFTP checks

Run `04-Start-TFTP.command` only after Mac Ethernet has `192.168.1.254/24`. Its custom service uses the built-in Mac server with a restricted root and no upload/create option. A self-test failure is a STOP before flashing.

Read-only checks on MAC:

```sh
sudo launchctl print system/local.hx21.openwrt.tftpd
sudo lsof -nP -iUDP:69
networksetup -listallhardwareports
```

For packet observation, identify the actual wired `enN` device first; replace the placeholder:

```sh
sudo tcpdump -ni enN 'udp and host 192.168.1.1'
```

Stop capture with Ctrl-C. TFTP begins on UDP/69 but data transfers use another UDP port; filtering only port 69 can hide the data. Do not leave packet captures running unnecessarily.

- No request: check router boot stage, Ethernet port/link, Mac IP and exact filename.
- Requests but no transfer: investigate macOS Local Network permission, firewall rules and server status. Allow the required local service narrowly. Do not leave a global firewall disablement in place or troubleshoot on a public network.
- File-not-found: the recovery filename must be exactly `openwrt-mediatek-filogic-imou_hx21-initramfs-recovery.itb`, with no version string or extra extension.
- A different TFTP server already owns port 69: the helper refuses to displace it; inspect that service instead of killing unknown processes.

## New OpenWrt U-Boot still works, OS does not

The [device recovery procedure](https://openwrt.org/toh/imou/hx21) uses the same recovery file and Mac server at `192.168.1.254`. With no flash write currently running, power off the router; hold Reset while powering on, then release after about 10 seconds. Wait for recovery, inspect board identity, then validate and install the correct HX21 sysupgrade image as in the main guide. This recovery may rewrite UBI data.

UART bootmenu labels matter more than numeric shortcuts. In the checked upstream HX21 U-Boot source, **1 = boot via TFTP, 7 = write BL2, 8 = reboot**. Some group instructions used conflicting numbers. Never select a bootloader-write menu entry merely to load a recovery image. This kit's TFTP directory intentionally contains only the recovery image; it does not serve bootloader files automatically.

## BL2/FIP damaged: ordinary TFTP may be unavailable

An intact U-Boot is needed for its TFTP recovery. When BL2 or FIP is destroyed, the official page points to [mtk_uartboot](https://github.com/981213/mtk_uartboot) and a proper 3.3 V UART connection. That is a hardware recovery workflow with board-specific payload/boot-stage requirements, not a generic `screen` command. No prebuilt UART executable, guessed wiring, or unattended recovery script is included. Get an appropriate adapter and expert help before proceeding if this risk is unacceptable.

## Return to stock

The device wiki DOES document a stock-return procedure. It restores your original bootloader components and stock UBI, with flash-write protection handling where necessary. It is not a stock firmware image uploaded to LuCI, nor a guaranteed one-click rollback.

This kit keeps the prerequisites: original BL2, FIP, u-boot-env, Factory, UBI and whole-device dumps, their sizes, maps and checksums. Stock/OpenWrt partition layouts differ. Before restoring, review the current map, bootloader state, NAND bad-block handling and actual backup set with the [current official return-to-stock section](https://openwrt.org/toh/imou/hx21#return_to_stock). There is intentionally no automatic raw-restore script. Do not flash the whole 128 MB dump blindly, restore someone else's Factory partition, or treat a web config export as a NAND image.

## Cleanup if a helper is interrupted

Run `05-Stop-TFTP-and-Remove-Alias.command`. It unloads only `local.hx21.openwrt.tftpd` and removes the kit's recorded `192.168.10.2` alias. If bookkeeping was not written before interruption, inspect `ifconfig` first and remove that address only from the confirmed Ethernet device with `sudo ifconfig enN -alias 192.168.10.2`. Restore the previous primary IPv4/DNS settings in System Settings yourself. The service is not installed as a persistent LaunchDaemon; rebooting the Mac ends it. Temporary public firmware staging files are retained in `/private/tmp` for diagnosis; private backups stay in this folder.
