# Preparation checks — 2026-09-02

Passed on this Mac (Apple silicon / macOS 26.6):

- All four official firmware downloads matched `sha256sums` and the `imou_hx21` entries in official `profiles.json`.
- Published profile supported-device identifier: `imou,hx21`; release 25.12.5.
- Firmware sizes matched profile metadata: FIP 804596 bytes; preloader 230232; recovery 9109504; sysupgrade 10969346.
- The unversioned TFTP recovery copy is byte-for-byte identical to the verified versioned image.
- Optional SSH configuration, optional kernel module, downloaded public key and profile metadata have recorded local SHA-256 hashes.
- All `.sh` / `.command` files parsed under the Mac's `/bin/bash`.
- Custom TFTP plist passed `plutil -lint`; server flags/socket keys cross-checked against local macOS manuals.
- Required macOS SSH/SCP/checksum/TFTP/launchd tools exist. No Homebrew installation is required for the main helpers.
- Stock-layout validator accepted the documented six-partition layout and rejected a changed Factory label, changed UBI size, missing partition, unexpected extra partition and duplicate partition.
- Three SSH profiles parsed with `ssh -G`; that does not contact a router.
- Double-click helpers marked executable; kit/backups/state directories restricted to the user.

NOT performed:

- GPG detached-signature verification (GnuPG absent; signed records/key/instructions included).
- Applying or safety-auditing the community SSH configuration.
- Any SSH connection, partition read, reboot or write on your router.
- Starting TFTP, binding UDP/69, changing Mac IPs, disabling firewall, enabling Local Network permission or installing anything globally.
- Physical router/revision/adapter identification or a live flashing/recovery test.

The TFTP helper performs a real local transfer test only when you start it; the backup helper validates actual device sizes and readback hashes only when you run it. Hardware compatibility and successful recovery cannot be certified from offline preparation.

Rerun offline checks without contacting a router:

```sh
cd ~/Desktop/HX21-OpenWrt-Mac-Kit
/bin/bash scripts/test-offline.sh
```
