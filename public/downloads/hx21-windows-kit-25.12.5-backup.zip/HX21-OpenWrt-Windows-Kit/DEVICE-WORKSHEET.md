# PRIVATE — fill locally; never upload

- Model/revision:
- Stock version:
- Original sticker/WAN/LAN/radio MACs:
- ISP details stored privately at:
- Backup before/after SSH unlock:
- Verified stock map and hashes:
- Second private backup location:
- Previous Windows Ethernet/DNS/DHCP settings:
- Temporary firewall rule to remove:
- Recovery plan:
